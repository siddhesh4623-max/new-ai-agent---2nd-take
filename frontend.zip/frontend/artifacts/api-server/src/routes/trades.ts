import { Router } from "express";
import fs from "fs";

const router = Router();

// Default matches engine.py JOURNAL_FILE — override with TRADES_CSV_PATH env var
const TRADES_FILE = process.env.TRADES_CSV_PATH ?? "trades_journal.csv";

interface TradeRow {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  status: "OPEN" | "CLOSED";
  entryTime: string;
  entryPrice: number;
  exitTime: string | null;
  exitPrice: number | null;
  moveUsd: number | null;
  pnlUsdt: number | null;
  qty: number;
  entryGap: number;
  exitReason: string | null;
  heldS: number | null;
}

// Parses the bot's trades_journal.csv format:
// trade_no,symbol,side,entry_time,exit_time,held_s,entry_price,exit_price,move_usd,pnl_usdt,exit_reason,entry_gap
function parseCSV(content: string): TradeRow[] {
  const lines = content.split("\n").filter((l) => l.trim().length > 0);
  if (lines.length < 2) return [];

  const rows: TradeRow[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",");
    if (cols.length < 10) continue;

    const [
      tradeNo,
      symbol,
      side,
      entryTime,
      exitTime,
      heldS,
      entryPrice,
      exitPrice,
      moveUsd,
      pnlUsdt,
      exitReason,
      ...entryGapParts
    ] = cols;

    const entryGap = entryGapParts.join(",").trim();

    rows.push({
      id: parseInt(tradeNo) || i,
      symbol: symbol?.trim() || "BTCUSDT",
      side: (side?.trim().toUpperCase() as "LONG" | "SHORT") || "LONG",
      status: "CLOSED",
      entryTime: entryTime?.trim() || "",
      entryPrice: parseFloat(entryPrice) || 0,
      exitTime: exitTime?.trim() || null,
      exitPrice: exitPrice?.trim() ? parseFloat(exitPrice) : null,
      moveUsd: moveUsd?.trim() ? parseFloat(moveUsd) : null,
      pnlUsdt: pnlUsdt?.trim() ? parseFloat(pnlUsdt) : null,
      qty: 0.007,
      entryGap: parseFloat(entryGap) || 0,
      exitReason: exitReason?.trim() || null,
      heldS: heldS?.trim() ? parseFloat(heldS) : null,
    });
  }

  // Re-index after reversing so IDs are globally unique across bot sessions
  return rows.reverse().map((row, i) => ({ ...row, id: i + 1 }));
}

router.get("/trades", (req, res) => {
  try {
    if (!fs.existsSync(TRADES_FILE)) {
      res.json({ trades: [] });
      return;
    }
    const content = fs.readFileSync(TRADES_FILE, "utf-8");
    const trades = parseCSV(content);
    res.json({ trades });
  } catch {
    res.json({ trades: [] });
  }
});

export default router;
