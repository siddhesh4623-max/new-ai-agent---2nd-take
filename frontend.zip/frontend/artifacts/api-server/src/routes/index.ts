import { Router, type IRouter } from "express";
import healthRouter from "./health";
import logsRouter from "./logs";
import positionRouter from "./position";
import tradesRouter from "./trades";

const router: IRouter = Router();

router.use(healthRouter);
router.use(logsRouter);
router.use(positionRouter);
router.use(tradesRouter);

export default router;
