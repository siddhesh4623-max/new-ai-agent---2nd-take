import { Router } from "express";
import fs from "fs";

const router = Router();

const LOG_FILE = "/tmp/bot.log";
const MAX_LINES = 200;

router.get("/logs", (req, res) => {
  const since = parseInt(String(req.query.since ?? "0"));

  try {
    if (!fs.existsSync(LOG_FILE)) {
      res.json({ logs: [], total: 0, since: 0 });
      return;
    }

    const content = fs.readFileSync(LOG_FILE, "utf-8");
    const allLines = content.split("\n").filter((l) => l.trim().length > 0);
    const total = allLines.length;

    const newLines = allLines.slice(Math.max(0, since));
    const trimmed = newLines.slice(-MAX_LINES);

    res.json({
      logs: trimmed,
      total,
      since: Math.max(0, total - trimmed.length),
    });
  } catch {
    res.json({ logs: [], total: 0, since: 0 });
  }
});

export default router;
