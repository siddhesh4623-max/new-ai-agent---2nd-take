import { useEffect, useRef, useState } from "react";

export interface TradeEntry {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  entryTime: Date;
  entryPrice: number;
  exitTime: Date | null;
  exitPrice: number | null;
  moveUsd: number | null;
  pnlUsdt: number | null;
  exitReason: string | null;
  entryGap: number;
  qty: number;
  status: "OPEN" | "CLOSED";
  unrealisedPnl: number | null;
  heldS: number | null;
}

interface ApiRow {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  status: "OPEN" | "CLOSED";
  // bot writes "2026-03-14 11:33:33" (UTC, no TZ suffix)
  entryTime: string;
  entryPrice: number;
  exitTime: string | null;
  exitPrice: number | null;
  moveUsd: number | null;
  pnlUsdt: number | null;
  qty: number;
  entryGap: number;
  exitReason: string | null;
  heldS: number | null;
}

function parseDate(s: string | null): Date | null {
  if (!s) return null;
  // "2026-03-14 11:33:33" → treat as UTC
  const normalized = s.trim().replace(" ", "T") + "Z";
  const d = new Date(normalized);
  return isNaN(d.getTime()) ? null : d;
}

function toEntry(row: ApiRow): TradeEntry {
  return {
    id: row.id,
    symbol: row.symbol,
    side: row.side,
    status: row.status,
    entryTime: parseDate(row.entryTime) ?? new Date(0),
    entryPrice: row.entryPrice,
    exitTime: parseDate(row.exitTime),
    exitPrice: row.exitPrice,
    moveUsd: row.moveUsd,
    pnlUsdt: row.pnlUsdt,
    exitReason: row.exitReason,
    entryGap: row.entryGap,
    qty: row.qty,
    heldS: row.heldS,
    unrealisedPnl: null,
  };
}

function computeStats(trades: TradeEntry[]) {
  const closed = trades.filter((t) => t.status === "CLOSED");
  const open = trades.filter((t) => t.status === "OPEN");
  const wins = closed.filter((t) => (t.pnlUsdt ?? 0) > 0).length;
  const losses = closed.filter((t) => (t.pnlUsdt ?? 0) <= 0).length;
  const totalPnl = closed.reduce((s, t) => s + (t.pnlUsdt ?? 0), 0);
  return {
    totalTrades: trades.length,
    openTrades: open.length,
    wins,
    losses,
    totalPnl: parseFloat(totalPnl.toFixed(4)),
    winRate: closed.length > 0 ? Math.round((wins / closed.length) * 100) : 0,
  };
}

export function useTradeJournal(pollMs = 3000) {
  const [trades, setTrades] = useState<TradeEntry[]>([]);
  const [stats, setStats] = useState({
    totalTrades: 0,
    openTrades: 0,
    wins: 0,
    losses: 0,
    totalPnl: 0,
    winRate: 0,
  });
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;

    const fetchTrades = async () => {
      try {
        const res = await fetch("/api/trades");
        if (!res.ok) return;
        const data = await res.json();
        if (!mountedRef.current) return;

        const entries: TradeEntry[] = (data.trades ?? []).map(toEntry);
        setTrades(entries);
        setStats(computeStats(entries));
      } catch {
        // silently ignore — will retry on next poll
      }
    };

    fetchTrades();
    const id = setInterval(fetchTrades, pollMs);
    return () => {
      mountedRef.current = false;
      clearInterval(id);
    };
  }, [pollMs]);

  return { trades, stats };
}
